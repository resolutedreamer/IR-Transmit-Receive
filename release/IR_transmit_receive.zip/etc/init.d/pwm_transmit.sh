#!/bin/sh
/bin/pwm_transmit

