#!/bin/sh
python /etc/init.d/notify_ip.py
