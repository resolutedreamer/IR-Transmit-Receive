#include "mcu_api.h"
#include "mcu_errno.h"

void mcu_main()
{
    /* your configuration code starts here */

    while (1)       /* your loop code starts here */
    {
    }
}
